# Giveaway Bot

<i>Да-да, первый нормальный в паблик доступе который не побанит вам аккаунты и работает.</i>

<b>Преимущества перед ботами недокодеров типа назавода:</b>
<b>1. </b>Нормальное сохранение сессий, работа с дискорд апи и возможность юзать прокси. 

<b>2. </b>Если использовать прокси то словить бан за использование такого бота практически невозможно. 

<b>3. </b>Нормальный код.  

<b>Гайд по установке &gt;</b> https://telegra.ph/Ustanovka-Giveaway-bota-05-27

<b>Скачать &gt;</b> https://github.com/scissoreth/giveaway_bot/archive/refs/heads/master.zip

<b>Основные эмодзи (чтобы не искали в инете) &gt;</b> https://t.me/crypto_satana/3

<a href="https://t.me/crypto_satana">Maded by Crypto $atana with ❤️</a>
